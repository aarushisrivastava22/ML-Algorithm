#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
unsigned short numbeg; 
int getdigit(short numbeg,int position);    
int position;
int k;  
int x; 
//int p;  
int saver; 
int main(int argc, char*argv[])
{ 
if(argc<1){ 
  printf("Invalid argument");  
}
// printf("enter a number"); 
 //scanf("%hu", &numbeg); 
   numbeg = atoi(argv[1]);  
 for(k=0; k<8; k++){ 
  x = getdigit(numbeg,k);
  saver = x; 
  x = getdigit(numbeg,15-k);

    
  if(saver!=x){  
         printf("Not-Palindrome "); 
      return 0;   
    }
 

}
printf("Is-Palindrome"); 

return 0; 
}

int getdigit(short numbeg,int position){
short  b; 
if(position>31) {
 printf("error:out of range"); 
}
else {
  b = numbeg>>position;
  x = b&1; 
  return x;  
} 
return 0; 
} 
 
