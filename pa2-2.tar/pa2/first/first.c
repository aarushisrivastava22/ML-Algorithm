#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
int getfunction(int numbeg, int n);
unsigned short  numbeg;
int complementfunction(int numbeg, int n);
int setfunction(int numbeg, int n, int v); 
int main(int argc, char**argv)
{
FILE *fptr;
fptr = fopen(argv[1], "r");
if(fptr == NULL){
    printf("error"); 
    return 0;  
} 
char word[100];
int n;
int v; 
while(!feof(fptr)){
    fscanf(fptr, "%hu\n", &numbeg);
    fscanf(fptr, "%s\t%d\t\%d\n",word, &n,&v); 
    if(strcmp(word,"get") ==0){
       getfunction(numbeg,n);  
    }
    if(strcmp(word,"set")==0){
      numbeg = setfunction(numbeg,n,v);  
     }
    if(strcmp(word,"comp")==0){
     numbeg = complementfunction(numbeg, n);  
    }
}
printf("\n");
fclose(fptr); 
return 0;  
}

//*

int getfunction(int numbeg, int n)
{
 int b; 
 int y; 
 
 // unsigned short  z;
 // z=numbeg&0;
  if( n>31){
   printf("error:out of range"); 
  } 
  else{
   b = numbeg >> n;  
   y = b & 1;
   printf("%d", y); 
   printf("\n"); 
   return y; 
  }
  return 0;
}

//*

int complementfunction(int numbeg, int n){
int b; 
int y;
int z;  
if(n>31){
 printf("error: out of range"); 
}
else{
 b = numbeg>>n;
 y = b & 1; 
 if (y == 0) {
      z = numbeg | (1<<n);  
     printf("%d", z);
     printf("\n");   
     return z;  
   }
  if(y == 1) {
      z = numbeg & ~(1 << n); 
     printf("%d", z);
     printf("\n");   
     return z;
} 
}
return 0; 
}

//*

int setfunction(int numbeg, int n, int v) {
// same- don't do anything or else switch)
//printf("these are the parameters");
//printf("%d", "%d","%d", numbeg, n,v);
//printf("\n");  
int b;
int y; 
int z; 

if(n>31){
printf("Error:out of range"); 
}
else{
b = numbeg>>n; 
y = b & 1;
//printf("Set function y "); 
//printf("%d", y);

if(y == v){
   z= numbeg;
   printf("%d", z); 
   printf("\n"); 
   return z;  
}
   
 if(y ==0) {
    z = numbeg | (1<<n);
   // printf("This is y =0  "); 
    printf("%d", z);
    printf("\n"); 
    return z;   
}
if( y == 1) {
     z = numbeg & ~(1 <<n);
 //   printf("This is y == 1  "); 
    printf("%d", z);
    printf("\n"); 
    return z;  
}
}
return 0;  
}
