#include <stdio.h>
#include <stdlib.h>
#include <string.h>
unsigned short  numbeg;
int getfunction(short numbeg);
int y; 
int main(int argc, char*argv[])
{  
  int k;
  int countparity; 
   countparity = 0;  
  k = 16;
  int foundone; 
  foundone = 0;
  int counteven;    
  // printf("enter an number:  "); 
  // scanf("%hu",&numbeg);
   if(argc<1) {
  printf("Don't feed me arguments"); 
  }
    numbeg  = atoi(argv[1]); 

    while(k>0) {  
    y = getfunction(numbeg);
if((foundone==1) && (y ==1)){
      counteven = counteven +1; 
      countparity = countparity + 1; 
      foundone = 0;  
    }  
   else if(y == 1){
        counteven = counteven +1; 
        foundone = 1;  
     } 
   else if(y != 1) {
     foundone = 0; 
   }
   k--; 
   numbeg = numbeg >> 1; 
}
if((counteven&1) == 0){
 printf("Even-Parity"); 
}
if((counteven&1) == 1){
 printf("Odd-Parity"); 
} 
printf("\t%d", countparity); 
}
int getfunction(short  numbeg)
{
 int n;
 int b;
 n =0; 
  if( n>31){
   printf("error:out of range");
  }
  else{
   b = numbeg >> n;
   y = b & 1;
   return y;
  }
  return 0;
}

